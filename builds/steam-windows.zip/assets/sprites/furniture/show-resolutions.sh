identify *.png | cut -d " " -f 1,3
